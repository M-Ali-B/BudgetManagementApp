package com.github.malib.budgetmanagementapp.Modal;

public class MyData {


    String title ;
    String description;
    String budget;
    String date;
    String id;


    public MyData() {
    }

    public MyData(String title, String description, String budget, String date, String id) {
        this.title = title;
        this.description = description;
        this.budget = budget;
        this.date = date;
        this.id = id;
    }
}
